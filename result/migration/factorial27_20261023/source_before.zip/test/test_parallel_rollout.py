from __future__ import annotations

import json
import random
import time
from copy import deepcopy

import numpy as np
import pytest
import torch

import agent.ppo.parallel as parallel_module
from agent.ppo import PPOAgent, build_actor_critic
from agent.ppo.buffer import RolloutBuffer
from agent.ppo.parallel import (
    EVALUATION_WORKER_TIMING_FIELDS,
    ParallelEpisodeRunner,
    ParallelWorkerError,
    ParallelWorkerTimeout,
    WorkerProgress,
    WorkerResponse,
    _worker_roll_forward,
    physical_forced_action_from_mask,
)
from configs import load_config
from data.dataset import OnlineInstanceDataset, load_dataset_split, build_dataset_split
from environment import AssemblySchedulingEnv, RewardVector
from eval import (
    EvaluationPolicy,
    evaluate_dataset,
    evaluate_dataset_parallel,
    evaluate_instance,
)


def _prepare_bounded_validation(config, template, tmp_path, count):
    # The reduced decision budget is a distinct environment contract.
    config["paths"]["instances_root"] = str(tmp_path / "instances")
    config["paths"]["manifests_root"] = str(tmp_path / "manifests")
    build_dataset_split(config=config, template=template, split="validation", count=count)


def _agent(config, instance):
    environment = AssemblySchedulingEnv(config)
    observation = environment.reset(instance)
    network = build_actor_critic(observation, config["network"])
    return PPOAgent(network, config["ppo"], device="cpu")


class _CommandConnection:
    def __init__(self, commands):
        self.commands = iter(commands)
        self.responses = []
        self.closed = False

    def recv(self):
        return next(self.commands)

    def send(self, response):
        self.responses.append(response)

    def close(self):
        self.closed = True


def test_historical_evaluation_worker_does_not_construct_training_data(config, fixed_instance, tmp_path, monkeypatch):
    historical = deepcopy(config)
    historical["generator"]["curriculum"] = {"anchors": []}
    historical["paths"]["training_instances_cache"] = str(tmp_path / "cache")
    monkeypatch.setattr(parallel_module, "OnlineInstanceDataset",
                        lambda **kwargs: pytest.fail("evaluation constructed training data"))
    connection = _CommandConnection([("reset_instance", fixed_instance), ("close", None)])
    parallel_module._worker_main(0, connection, historical, fixed_instance, 2000)
    assert connection.closed
    assert len(connection.responses) == 3
    assert all(isinstance(response, WorkerResponse) for response in connection.responses)
    assert connection.responses[1].observation is not None
    assert not (tmp_path / "cache").exists()


@pytest.mark.parametrize("command", ["reset_online", "generate_online"])
def test_historical_worker_rejects_online_training(config, fixed_instance, tmp_path, command):
    historical = deepcopy(config)
    historical["generator"]["severity_curriculum"] = {"anchors": []}
    historical["paths"]["training_instances_cache"] = str(tmp_path / "cache")
    connection = _CommandConnection([(command, 0)])
    parallel_module._worker_main(0, connection, historical, fixed_instance, 2000)
    failure = connection.responses[-1]
    assert isinstance(failure, parallel_module.WorkerFailure)
    assert failure.command == command
    assert "evaluation and analysis only" in failure.message
    assert connection.closed and not (tmp_path / "cache").exists()


class _FakeObservation:
    def __init__(self, state: int):
        self.state = state

    def copy(self):
        return _FakeObservation(self.state)


class _LocalForcedChainEnvironment:
    def __init__(self, masks, physical, *, terminate_at=None):
        self.masks = [np.asarray(mask, dtype=np.bool_) for mask in masks]
        self.physical = list(physical)
        self.terminate_at = terminate_at
        self.state = 0
        self.terminated = False
        self.truncated = False
        self.build_observation_flags: list[bool] = []

    def get_action_mask(self):
        return self.masks[self.state].copy()

    def forced_action_diagnostic(self, action_mask):
        legal = np.flatnonzero(~np.asarray(action_mask, dtype=np.bool_))
        if legal.size != 1:
            return None
        physical = bool(self.physical[self.state])
        action_kind = (
            "wait"
            if int(legal[0]) == len(action_mask) - 1
            else "pair"
        )
        return {
            "wait_physically_unavailable": (
                physical and action_kind == "pair"
            ),
            "pair_physically_unavailable": (
                physical and action_kind == "wait"
            ),
        }

    def step(self, action, *, build_observation=True):
        assert not self.get_action_mask()[int(action)]
        self.build_observation_flags.append(bool(build_observation))
        self.state += 1
        self.terminated = self.state == self.terminate_at
        observation = (
            _FakeObservation(self.state)
            if build_observation and not self.terminated
            else None
        )
        reward = RewardVector(
            flow=float(self.state),
            cost=-float(self.state),
            variance=0.5,
        )
        return observation, reward, self.terminated, False, {}

    def observe(self):
        return _FakeObservation(self.state)

    def metrics(self):
        return {"state": self.state}

    def validate_schedule(self):
        return []


def test_physical_forced_detection_accepts_pair_and_wait_singletons():
    physical_pair = _LocalForcedChainEnvironment(
        [[False, True]],
        [True],
    )
    physical_wait = _LocalForcedChainEnvironment(
        [[True, False]],
        [True],
    )
    non_physical_pair = _LocalForcedChainEnvironment(
        [[False, True]],
        [False],
    )

    assert physical_forced_action_from_mask(
        physical_pair,
        physical_pair.get_action_mask(),
    ) == 0
    assert physical_forced_action_from_mask(
        physical_wait,
        physical_wait.get_action_mask(),
    ) == 1
    assert physical_forced_action_from_mask(
        non_physical_pair,
        non_physical_pair.get_action_mask(),
    ) is None


def test_worker_local_roll_forward_stops_at_policy_or_step_budget():
    environment = _LocalForcedChainEnvironment(
        [
            [True, False],
            [False, True],
            [False, False],
        ],
        [True, True, False],
    )
    response = _worker_roll_forward(
        0,
        environment,
        _FakeObservation(0),
        preserve_graph=True,
        requested_action=None,
        drain_physical_forced_actions=True,
        max_environment_steps=None,
    )
    assert response.environment_step_count == 2
    assert response.local_physical_forced_action_count == 2
    assert response.observation.state == 2
    assert np.count_nonzero(~response.action_mask) == 2
    assert response.reward_vector.flow == pytest.approx(3.0)
    assert response.reward_vector.cost == pytest.approx(-3.0)
    assert environment.build_observation_flags == [False, False]

    budgeted = _LocalForcedChainEnvironment(
        [
            [True, False],
            [False, True],
            [False, False],
        ],
        [True, True, False],
    )
    response = _worker_roll_forward(
        0,
        budgeted,
        _FakeObservation(0),
        preserve_graph=True,
        requested_action=None,
        drain_physical_forced_actions=True,
        max_environment_steps=1,
    )
    assert response.environment_step_count == 1
    assert response.local_physical_forced_action_count == 1
    assert response.observation.state == 1
    assert budgeted.build_observation_flags == [False]


def test_worker_local_roll_forward_aggregates_terminal_suffix():
    environment = _LocalForcedChainEnvironment(
        [
            [False, False],
            [True, False],
        ],
        [False, True],
        terminate_at=2,
    )
    response = _worker_roll_forward(
        0,
        environment,
        _FakeObservation(0),
        preserve_graph=True,
        requested_action=0,
        drain_physical_forced_actions=True,
        max_environment_steps=2,
    )
    assert response.terminated
    assert response.environment_step_count == 2
    assert response.local_physical_forced_action_count == 1
    assert response.reward_vector.flow == pytest.approx(3.0)
    assert response.metrics["state"] == 2
    assert response.metrics["schedule_violations"] == []
    assert environment.build_observation_flags == [False, False]


def test_worker_timer_includes_observe_after_step_and_initial_reset(monkeypatch):
    clock = [10.0]
    monkeypatch.setattr(parallel_module.time, "perf_counter", lambda: clock[0])

    class TimedEnvironment(_LocalForcedChainEnvironment):
        _observation_time_seconds = 0.3

        def step(self, *args, **kwargs):
            clock[0] += 0.2
            return super().step(*args, **kwargs)

        def observe(self):
            clock[0] += 0.7
            self._observation_time_seconds += 0.7
            return super().observe()

        def metrics(self):
            clock[0] += 0.1
            return super().metrics()

    env = TimedEnvironment([[False, False]] * 3, [False] * 3, terminate_at=2)
    reset = _worker_roll_forward(0, env, _FakeObservation(0), preserve_graph=True,
                                requested_action=None, drain_physical_forced_actions=False,
                                max_environment_steps=None, reset_time_seconds=0.5)
    assert reset.observation_time_seconds == pytest.approx(0.3)
    assert reset.worker_service_time_seconds == pytest.approx(0.5)
    step = _worker_roll_forward(0, env, None, preserve_graph=True, requested_action=0,
                               drain_physical_forced_actions=False, max_environment_steps=None)
    assert step.environment_step_time_seconds == pytest.approx(0.2)
    assert step.observation_time_seconds == pytest.approx(0.7)
    assert step.worker_service_time_seconds == pytest.approx(0.9)
    terminal = _worker_roll_forward(0, env, None, preserve_graph=True, requested_action=0,
                                   drain_physical_forced_actions=False, max_environment_steps=None)
    assert terminal.observation_time_seconds == 0
    assert terminal.terminal_metrics_time_seconds == pytest.approx(0.1)
    assert terminal.worker_service_time_seconds == pytest.approx(0.3)


def test_parallel_training_seeds_and_cleanup(
    config,
    fixed_instance,
    monkeypatch,
    tmp_path,
):
    effective_config = deepcopy(config)
    effective_config["training"]["worker_timeout_seconds"] = 120
    agent = _agent(effective_config, fixed_instance)
    monkeypatch.setattr(
        agent,
        "value_batch",
        lambda observations, masks: [7.0] * len(observations),
    )
    processes = []
    with ParallelEpisodeRunner(
        config=effective_config,
        template=fixed_instance,
        episode_count=2,
        worker_count=2,
        diagnostic_directory=tmp_path,
    ) as runner:
        processes = list(runner._processes)
        rollout = runner.collect_training_batch(
            agent,
            [0, 1],
            gamma=float(effective_config["ppo"]["gamma"]),
            gae_lambda=float(effective_config["ppo"]["gae_lambda"]),
            step_limit=1,
        )
        assert [value.episode_index for value in rollout.episodes] == [0, 1]
        assert [value.metadata["seed"] for value in rollout.episodes] == [
            1_000_000,
            1_000_001,
        ]
        assert rollout.transition_count == 2
        assert all(len(value.buffer) == 1 for value in rollout.episodes)
        assert all(
            episode.buffer.transitions[0].done is False
            and episode.buffer.transitions[0].return_value
            == pytest.approx(episode.buffer.transitions[0].reward + 7.0)
            for episode in rollout.episodes
        )
        from train import _episode_log_row, training_distribution_summary
        timing_rows = [_episode_log_row(episode) for episode in rollout.episodes]
        for episode, row in zip(rollout.episodes, timing_rows):
            assert episode.observation_time_seconds > 0
            assert episode.worker_service_time_seconds >= episode.observation_time_seconds
            assert episode.reset_time_seconds > 0
            assert episode.terminal_metrics_time_seconds > 0  # cutoff snapshot
            for name in EVALUATION_WORKER_TIMING_FIELDS:
                assert row[name] == getattr(episode, name)
        totals = training_distribution_summary(timing_rows)
        assert totals["observation_time_seconds"] == sum(episode.observation_time_seconds for episode in rollout.episodes)
        assert all(
            value.base_reward_sum == pytest.approx(value.expected_reward)
            for value in rollout.episodes
        )
        assert all(
            set(value.reward_components)
            == {
                "flow",
                "cost",
                "variance",
                "workload",
                "operation_progress",
                "quality",
                "failure",
                "feasibility_shaping",
            }
            for value in rollout.episodes
        )
    assert processes
    assert all(not process.is_alive() for process in processes)
    events = _worker_events(tmp_path)
    assert len(events) == 4
    assert {event["event"] for event in events} == {"instance_start", "instance_end"}
    endings = [event for event in events if event["event"] == "instance_end"]
    assert all(event["terminal_reason"] == "step_limit" for event in endings)
    assert all(event["environment_step_count"] == 1 for event in endings)
    assert {event["seed"] for event in endings} == {1_000_000, 1_000_001}


def test_training_collector_refills_two_lanes_for_five_episodes(config, fixed_instance):
    effective_config = deepcopy(config)
    agent = _agent(effective_config, fixed_instance)
    with ParallelEpisodeRunner(
        config=effective_config,
        template=fixed_instance,
        episode_count=5,
        worker_count=3,
    ) as runner:
        reset_lanes = []
        original_exchange = runner._exchange

        def recording_exchange(commands):
            reset_lanes.extend(lane for lane, (command, _) in commands.items()
                               if command == "reset_online")
            return original_exchange(commands)

        runner._exchange = recording_exchange
        rollout = runner.collect_training_batch(
            agent, [0, 1, 2, 3, 4],
            gamma=float(effective_config["ppo"]["gamma"]),
            gae_lambda=float(effective_config["ppo"]["gae_lambda"]),
            step_limit=2,
            max_parallelism=2,
        )
    assert [episode.episode_index for episode in rollout.episodes] == list(range(5))
    assert rollout.transition_count == 10
    assert set(reset_lanes) == {0, 1}
    assert all(episode.base_reward_sum == pytest.approx(episode.expected_reward)
               for episode in rollout.episodes)


def test_environment_sampling_guard_keeps_critic_bootstrap(
    config,
    fixed_instance,
):
    effective_config = deepcopy(config)
    effective_config["environment"]["max_decisions"] = 1
    agent = _agent(effective_config, fixed_instance)
    environment = AssemblySchedulingEnv(effective_config)
    observation = environment.reset(fixed_instance)
    mask = environment.get_action_mask()
    action, log_probability, value = agent.act(observation, mask)
    _, reward, terminated, truncated, _ = environment.step(action)
    assert terminated is False
    assert truncated is True
    buffer = RolloutBuffer()
    buffer.add(
        observation,
        mask,
        action,
        log_probability,
        value,
        reward.scalarize(effective_config["reward"]),
        done=terminated,
    )
    buffer.compute_gae(last_value=123.0, gamma=1.0, gae_lambda=0.95)
    transition = buffer.transitions[0]
    assert environment.metrics()["sampling_truncated"] is True
    penalty = float(effective_config["reward"]["terminal_failure_penalty"])
    assert reward.failure == 0
    assert transition.done is False
    assert transition.return_value == pytest.approx(transition.reward + 123.0)


def test_parallel_collector_accepts_truncated_segment_reward_identity(
    config,
    fixed_instance,
):
    effective_config = deepcopy(config)
    effective_config["environment"]["max_decisions"] = 1
    environment = AssemblySchedulingEnv(effective_config)
    environment.reset(fixed_instance)
    action = int(np.flatnonzero(~environment.get_action_mask())[0])
    _, reward, _, truncated, _ = environment.step(action)
    assert truncated is True

    reward_components = {
        name: float(getattr(reward, name))
        for name in (
            "flow",
            "cost",
            "variance",
            "operation_progress",
            "quality",
            "failure",
            "feasibility_shaping",
        )
    }
    scalar_reward = reward.scalarize(effective_config["reward"])
    context = {
        "episode_index": 0,
        "instance_id": fixed_instance.instance_id,
        "metadata": {},
        "buffer": RolloutBuffer(),
        "reward_sum": scalar_reward,
        "reward_components": reward_components,
        "step_count": 1,
        "policy_step_count": 0,
        "forced_action_count": 1,
        "worker_step_command_count": 1,
        "worker_local_physical_forced_action_count": 0,
        "pending_transition": None,
        "policy_diagnostic_rows": [],
        "unattributed_forced_reward": scalar_reward,
        "generation_time_seconds": 0.0,
        "environment_step_time_seconds": 0.0,
    }
    runner = object.__new__(ParallelEpisodeRunner)
    runner.config = effective_config
    episode = runner._episode_result(context, environment.metrics())
    assert episode.metrics["sampling_truncated"] is True
    penalty = float(effective_config["reward"]["terminal_failure_penalty"])
    assert episode.reward_components["failure"] == 0
    assert episode.unshaped_reward_sum == pytest.approx(
        episode.expected_reward,
        abs=1e-8,
    )


def test_parallel_compression_skips_singleton_policy_masks(
    config,
    fixed_instance,
    monkeypatch,
):
    effective_config = deepcopy(config)
    effective_config["training"]["worker_timeout_seconds"] = 120
    effective_config["training"]["forced_action_compression"] = True
    effective_config["ppo"]["gamma"] = 1.0
    effective_config["ppo"]["gae_lambda"] = 0.995
    agent = _agent(effective_config, fixed_instance)
    original_act_batch = agent.act_batch
    policy_legal_action_counts: list[int] = []

    def tracked_act_batch(observations, action_masks, **kwargs):
        policy_legal_action_counts.extend(
            int(np.count_nonzero(~mask)) for mask in action_masks
        )
        return original_act_batch(observations, action_masks, **kwargs)

    monkeypatch.setattr(agent, "act_batch", tracked_act_batch)
    with ParallelEpisodeRunner(
        config=effective_config,
        template=fixed_instance,
        episode_count=1,
        worker_count=2,
    ) as runner:
        rollout = runner.collect_training_batch(
            agent,
            [0],
            gamma=1.0,
            gae_lambda=0.995,
            step_limit=64,
        )

    episode = rollout.episodes[0]
    assert policy_legal_action_counts
    assert min(policy_legal_action_counts) > 1
    assert episode.forced_action_count > 0
    assert episode.worker_local_physical_forced_action_count > 0
    assert episode.worker_step_command_count < episode.step_count
    assert episode.step_count == (
        episode.policy_step_count + episode.forced_action_count
    )
    assert episode.step_count == (
        episode.worker_step_command_count
        + episode.worker_local_physical_forced_action_count
    )
    assert rollout.environment_step_count == episode.step_count
    assert rollout.transition_count == episode.policy_step_count
    assert rollout.worker_step_command_count == (
        episode.worker_step_command_count
    )
    assert rollout.worker_local_physical_forced_action_count == (
        episode.worker_local_physical_forced_action_count
    )
    attributed_reward = sum(
        transition.reward for transition in episode.buffer.transitions
    )
    assert (
        attributed_reward + episode.unattributed_forced_reward
        == pytest.approx(episode.reward_sum, abs=1e-8)
    )


def test_worker_local_rollout_matches_round_trip_compression(
    config,
    fixed_instance,
):
    local_config = deepcopy(config)
    local_config["training"]["worker_timeout_seconds"] = 120
    local_config["training"]["forced_action_compression"] = True
    local_config["training"][
        "worker_local_physical_forced_actions"
    ] = True
    local_config["ppo"]["gamma"] = 1.0
    round_trip_config = deepcopy(local_config)
    round_trip_config["training"][
        "worker_local_physical_forced_actions"
    ] = False
    agent = _agent(local_config, fixed_instance)

    with ParallelEpisodeRunner(
        config=round_trip_config,
        template=fixed_instance,
        episode_count=1,
        worker_count=2,
    ) as runner:
        torch.manual_seed(24680)
        round_trip = runner.collect_training_batch(
            agent,
            [0],
            gamma=1.0,
            gae_lambda=float(local_config["ppo"]["gae_lambda"]),
            step_limit=64,
        ).episodes[0]
    with ParallelEpisodeRunner(
        config=local_config,
        template=fixed_instance,
        episode_count=1,
        worker_count=2,
    ) as runner:
        torch.manual_seed(24680)
        local = runner.collect_training_batch(
            agent,
            [0],
            gamma=1.0,
            gae_lambda=float(local_config["ppo"]["gae_lambda"]),
            step_limit=64,
        ).episodes[0]

    assert local.step_count == round_trip.step_count
    assert local.policy_step_count == round_trip.policy_step_count
    assert local.forced_action_count == round_trip.forced_action_count
    assert local.reward_sum == pytest.approx(round_trip.reward_sum, abs=1e-10)
    assert local.reward_components == pytest.approx(
        round_trip.reward_components,
        abs=1e-10,
    )
    for field in (
        "flow_time_objective",
        "reconfiguration_cost",
        "worker_load_variance",
        "terminal_reason",
        "completed_operations",
    ):
        assert local.metrics[field] == round_trip.metrics[field]
    assert local.worker_local_physical_forced_action_count > 0
    assert round_trip.worker_local_physical_forced_action_count == 0
    assert local.worker_step_command_count < (
        round_trip.worker_step_command_count
    )
    assert len(local.buffer) == len(round_trip.buffer)
    for local_transition, round_trip_transition in zip(
        local.buffer.transitions,
        round_trip.buffer.transitions,
    ):
        assert local_transition.action == round_trip_transition.action
        assert np.array_equal(
            local_transition.action_mask,
            round_trip_transition.action_mask,
        )
        for field in (
            "log_probability",
            "value",
            "reward",
            "advantage",
            "return_value",
        ):
            assert getattr(local_transition, field) == pytest.approx(
                getattr(round_trip_transition, field),
                abs=1e-4,
            )
        assert local_transition.done == round_trip_transition.done


def test_parallel_validation_matches_serial_and_preserves_rng(
    config,
    fixed_instance,
    tmp_path,
):
    effective_config = deepcopy(config)
    effective_config["training"]["worker_timeout_seconds"] = 120
    effective_config["environment"]["max_decisions"] = 50
    _prepare_bounded_validation(effective_config, fixed_instance, tmp_path, 2)
    agent = _agent(effective_config, fixed_instance)
    dataset = load_dataset_split(effective_config, "validation")
    processes = []
    with ParallelEpisodeRunner(
        config=effective_config,
        template=fixed_instance,
        episode_count=2,
        worker_count=2,
    ) as runner:
        processes = list(runner._processes)
        python_state = random.getstate()
        numpy_state = np.random.get_state()
        torch_state = torch.random.get_rng_state().clone()
        agent.network.train()
        parallel_rows, parallel = evaluate_dataset_parallel(
            effective_config,
            dataset_name="validation",
            ppo_agent=agent,
            runner=runner,
            instance_limit=2,
        )
        serial_rows, _, _, serial = evaluate_dataset(
            effective_config,
            dataset_name="validation",
            policy_name="ppo",
            ppo_agent=agent,
            instance_limit=2,
        )
        assert agent.network.training
        assert random.getstate() == python_state
        after_numpy = np.random.get_state()
        assert after_numpy[0] == numpy_state[0]
        assert np.array_equal(after_numpy[1], numpy_state[1])
        assert after_numpy[2:] == numpy_state[2:]
        assert torch.equal(torch.random.get_rng_state(), torch_state)
        assert [row["instance_id"] for row in parallel_rows] == [
            row["instance_id"] for row in serial_rows
        ]
        for parallel_row, serial_row in zip(
            parallel_rows,
            serial_rows,
        ):
            for field in (
                "terminated",
                "truncated",
                "termination_reason",
                "decisions",
                "makespan",
                "total_flow_time",
                "flow_time_objective",
                "reconfiguration_cost",
                "worker_load_variance",
                "schedule_violation_count",
            ):
                expected = serial_row[field]
                if isinstance(expected, float):
                    assert parallel_row[field] == pytest.approx(
                        expected,
                        abs=1e-8,
                    )
                else:
                    assert parallel_row[field] == expected
        assert parallel["completion_rate"] == serial["completion_rate"]
        assert parallel["truncated_count"] == serial["truncated_count"]
        assert dataset.manifest_path.exists()
    assert all(not process.is_alive() for process in processes)


def test_mixed_preference_quality_rollout_uses_episode_contexts(
    config,
    fixed_instance,
):
    effective_config = deepcopy(config)
    effective_config["training"]["worker_timeout_seconds"] = 120
    agent = _agent(effective_config, fixed_instance)
    with ParallelEpisodeRunner(
        config=effective_config,
        template=fixed_instance,
        episode_count=2,
        worker_count=2,
    ) as runner:
        batch = runner.collect_training_batch(
            agent,
            [0, 1],
            gamma=1.0,
            gae_lambda=float(effective_config["ppo"]["gae_lambda"]),
            step_limit=6,
            preferences=[(1.0, 0.0, 0.0), (0.0, 1.0, 0.0)],
        )
    expected = ([1.0, 0.0, 0.0], [0.0, 1.0, 0.0])
    assert len(batch.episodes) == 2
    for episode, preference in zip(batch.episodes, expected, strict=True):
        assert episode.metadata["preference"] == preference
        assert episode.metadata["preference_key"]
        assert episode.reward_sum == pytest.approx(
            episode.reward_components["operation_progress"]
            + episode.reward_components["quality"],
            abs=1e-8,
        )
        assert episode.reward_components["failure"] == 0.0
        assert episode.reward_components["workload"] == pytest.approx(episode.metrics["cumulative_reward"]["workload"])
        assert episode.reward_components["variance"] == pytest.approx(-episode.metrics["committed_worker_load_variance"])
        from train import _episode_log_row
        assert _episode_log_row(episode)["reward_workload"] == episode.reward_components["workload"]
        assert episode.metrics["task_failed"] is False
        assert all(
            transition.observation.preference.tolist() == preference
            for transition in episode.buffer.transitions
        )


def test_serial_and_parallel_ppo_preserve_the_same_preference(
    config,
    fixed_instance,
    tmp_path,
):
    effective_config = deepcopy(config)
    effective_config["device"] = "cpu"
    effective_config["environment"]["max_decisions"] = 50
    effective_config["training"]["worker_timeout_seconds"] = 120
    _prepare_bounded_validation(effective_config, fixed_instance, tmp_path, 1)
    agent = _agent(effective_config, fixed_instance)
    agent.network.eval()
    record = load_dataset_split(effective_config, "validation")[0]
    preference = (7.0, 2.0, 1.0)
    with ParallelEpisodeRunner(
        config=effective_config,
        template=fixed_instance,
        episode_count=1,
        worker_count=1,
    ) as runner:
        parallel = runner.evaluate_records(
            agent,
            [record],
            max_parallelism=1,
            deterministic=True,
            preferences=[preference],
        )[0]
    prepared = EvaluationPolicy(
        effective_config,
        policy_name="ppo",
        bootstrap_observation=AssemblySchedulingEnv(effective_config).reset(
            record.instance, preference=preference
        ),
        ppo_agent=agent,
        decode_mode="greedy",
    )
    _, serial = evaluate_instance(
        effective_config,
        instance=record.instance,
        policy_name="ppo",
        prepared_policy=prepared,
        preference=preference,
    )
    assert parallel.action_trace_sha256 == serial["action_trace_sha256"]
    assert parallel.metrics["preference"] == serial["preference"] == {
        "flow": 0.7,
        "cost": 0.2,
        "workload": pytest.approx(0.1),
    }
    assert parallel.metrics["preference_key"] == serial["preference_key"]
    for field in (
        "terminated",
        "truncated",
        "flow_time_objective",
        "reconfiguration_cost",
        "worker_load_variance",
    ):
        assert parallel.metrics[field] == pytest.approx(serial[field])


def test_sampled_validation_is_parallelism_invariant_and_preserves_rng(
    config,
    fixed_instance,
    tmp_path,
):
    effective_config = deepcopy(config)
    effective_config["training"]["worker_timeout_seconds"] = 120
    effective_config["environment"]["max_decisions"] = 30
    _prepare_bounded_validation(effective_config, fixed_instance, tmp_path, 10)
    agent = _agent(effective_config, fixed_instance)
    sampling_seed = 100011
    instance_limit = 10
    timing_fields = {
        "inference_time_seconds",
        "solve_time_seconds",
        "inference_time_per_decision_ms",
        "validation_parallel_envs",
        *EVALUATION_WORKER_TIMING_FIELDS,
    }

    random.seed(314)
    np.random.seed(314)
    torch.manual_seed(314)
    python_state = random.getstate()
    numpy_state = np.random.get_state()
    torch_state = torch.get_rng_state().clone()

    serial_rows, _, _, _ = evaluate_dataset(
        effective_config,
        dataset_name="validation",
        policy_name="ppo",
        ppo_agent=agent,
        instance_limit=instance_limit,
        decode_mode="sampled",
        sampling_seed=sampling_seed,
    )
    expected = [
        {
            key: value
            for key, value in row.items()
            if key not in timing_fields
        }
        for row in serial_rows
    ]

    with ParallelEpisodeRunner(
        config=effective_config,
        template=fixed_instance,
        episode_count=instance_limit,
        worker_count=10,
    ) as runner:
        for parallel_envs in (1, 2, 10):
            effective_config["training"][
                "validation_parallel_envs"
            ] = parallel_envs
            parallel_rows, aggregate = evaluate_dataset_parallel(
                effective_config,
                dataset_name="validation",
                ppo_agent=agent,
                runner=runner,
                instance_limit=instance_limit,
                decode_mode="sampled",
                sampling_seed=sampling_seed,
            )
            actual = [
                {
                    key: value
                    for key, value in row.items()
                    if key not in timing_fields
                }
                for row in parallel_rows
            ]
            assert actual == expected
            assert aggregate["parallel_envs"] == parallel_envs
            assert all(row["validation_parallel_envs"] == parallel_envs for row in parallel_rows)
            assert all(row["action_trace_sha256"] for row in parallel_rows)
            runtime = aggregate["evaluation_runtime"]
            assert runtime["policy_observation_count"] == sum(row["decisions"] for row in parallel_rows)
            assert runtime["policy_inference_seconds"] > 0
            assert runtime["main_receive_seconds"] > 0
            assert runtime["wall_seconds"] >= runtime["main_receive_seconds"]
            totals = aggregate["worker_timing_totals"]
            assert totals["observation_time_seconds"] > 0
            assert totals["worker_service_time_seconds"] >= totals["observation_time_seconds"]

    assert random.getstate() == python_state
    after_numpy = np.random.get_state()
    assert after_numpy[0] == numpy_state[0]
    assert np.array_equal(after_numpy[1], numpy_state[1])
    assert after_numpy[2:] == numpy_state[2:]
    assert torch.equal(torch.get_rng_state(), torch_state)


def test_reference_validation_sampler_for_before_after_benchmark(config, fixed_instance, tmp_path):
    effective = deepcopy(config)
    effective["environment"]["max_decisions"] = 5
    _prepare_bounded_validation(effective, fixed_instance, tmp_path, 2)
    agent = _agent(effective, fixed_instance)
    agent.network.execution_mode = "reference_v8"
    records = [load_dataset_split(effective, "validation")[index] for index in range(2)]
    with ParallelEpisodeRunner(
        config=effective, template=fixed_instance, episode_count=2, worker_count=2,
    ) as runner:
        rollouts = runner.evaluate_records(
            agent, records, max_parallelism=2, deterministic=False,
            sampling_seed=100011,
        )
    assert len(rollouts) == 2
    assert all(rollout.action_trace_sha256 for rollout in rollouts)


def test_parallel_worker_error_is_reported_and_all_workers_exit(
    config,
    fixed_instance,
    tmp_path,
):
    effective_config = deepcopy(config)
    effective_config["training"]["worker_timeout_seconds"] = 30
    processes = []
    with ParallelEpisodeRunner(
        config=effective_config,
        template=fixed_instance,
        episode_count=2,
        worker_count=2,
        diagnostic_directory=tmp_path,
    ) as runner:
        processes = list(runner._processes)
        runner._exchange({0: ("reset_instance", fixed_instance)})
        with pytest.raises(
            ParallelWorkerError,
            match="unknown worker command",
        ):
            runner._exchange({0: ("invalid-command", None)})
        runner._exchange({1: ("reset_instance", fixed_instance)})
    assert all(not process.is_alive() for process in processes)
    events = _worker_events(tmp_path)
    assert [event["event"] for event in events] == [
        "instance_start", "error", "instance_end", "instance_start", "instance_end",
    ]
    assert "unknown worker command" in events[1]["message"]
    assert events[1]["traceback"]
    assert events[1]["instance_id"] == fixed_instance.instance_id
    assert events[2]["terminal_reason"] == "error"
    assert events[0]["instance_task_id"] == events[2]["instance_task_id"]
    assert events[-1]["terminal_reason"] == "runner_closed"
    assert events[-1]["instance_task_id"] == events[-2]["instance_task_id"]


def test_training_cache_manifest_and_worker_progress_are_persistent(
    config,
    fixed_instance,
    tmp_path,
):
    effective = deepcopy(config)
    effective["paths"]["training_instances_cache"] = str(
        tmp_path / "cache"
    )
    effective["training"]["worker_timeout_seconds"] = 120
    effective["training"]["worker_stall_timeout_seconds"] = 30
    run_directory = tmp_path / "run"
    with ParallelEpisodeRunner(
        config=effective,
        template=fixed_instance,
        episode_count=2,
        worker_count=2,
        diagnostic_directory=run_directory,
    ) as runner:
        first = runner.pre_generate_training_instances()
    assert first["instance_count"] == 2
    assert first["cache_hit_count"] == 0
    assert first["cache_fingerprint"]
    assert (run_directory / "training_instance_manifest.json").exists()
    assert (run_directory / "training_instance_manifest.sha256").exists()
    assert (run_directory / "worker_progress.jsonl").exists()
    events = _worker_events(run_directory)
    assert len(events) == 4
    assert {event["event"] for event in events} == {"instance_start", "instance_end"}
    for ending in (event for event in events if event["event"] == "instance_end"):
        assert ending["terminal_reason"] == "generated"
        assert ending["instance_id"]
        assert ending["record_sha256"]
        assert sum(event["event"] == "instance_start" and
                   event["instance_task_id"] == ending["instance_task_id"]
                   for event in events) == 1

    second_run = tmp_path / "second_run"
    with ParallelEpisodeRunner(
        config=effective,
        template=fixed_instance,
        episode_count=2,
        worker_count=2,
        diagnostic_directory=second_run,
    ) as runner:
        second = runner.pre_generate_training_instances()
    assert second["cache_hit_count"] == 2
    assert [entry["sha256"] for entry in first["files"]] == [
        entry["sha256"] for entry in second["files"]
    ]
    assert all(event["cache_hit"] for event in _worker_events(second_run)
               if event["event"] == "instance_end")


def _worker_events(directory):
    return [json.loads(line) for line in
            (directory / "worker_progress.jsonl").read_text(encoding="utf-8").splitlines()]


def test_worker_step_debug_logging_preserves_sampled_trajectory(config, fixed_instance, tmp_path):
    effective = deepcopy(config)
    effective["environment"]["max_decisions"] = 5
    effective["training"]["slow_instance_seconds"] = 120
    _prepare_bounded_validation(effective, fixed_instance, tmp_path, 1)
    record = load_dataset_split(effective, "validation")[0]
    agent = _agent(effective, fixed_instance)
    agent.network.eval()
    rollouts = []
    for debug in (False, True):
        effective["logging"]["worker_progress"]["debug_steps"] = debug
        directory = tmp_path / str(debug)
        with ParallelEpisodeRunner(
            config=effective, template=fixed_instance, episode_count=1,
            worker_count=1, diagnostic_directory=directory,
        ) as runner:
            rollout = runner.evaluate_records(
                agent, [record], max_parallelism=1, deterministic=False,
                sampling_seed=100011,
            )[0]
        rollouts.append(rollout)
        events = _worker_events(directory)
        assert events[0]["event"] == "instance_start"
        assert events[-1]["event"] == "instance_end"
        assert events[0]["instance_task_id"] == events[-1]["instance_task_id"]
        assert events[-1]["instance_id"] == record.instance.instance_id
        assert events[-1]["environment_step_count"] == rollout.decisions
        assert events[-1]["truncated"] == rollout.metrics["truncated"]
        assert not any(event["event"] == "heartbeat" for event in events)
        assert len([event for event in events if event["event"] == "response"]) == (
            rollout.decisions if debug else 0
        )
    assert rollouts[0].action_trace_sha256 == rollouts[1].action_trace_sha256
    assert rollouts[0].metrics == rollouts[1].metrics


@pytest.mark.parametrize("debug", [False, True])
@pytest.mark.parametrize("outcome,slow_seconds", [
    ("completed", 100), ("completed", 0.1),
    ("stall_timeout", 100), ("hard_timeout", 100),
])
def test_worker_heartbeats_stay_in_memory_and_preserve_timeouts(
    config, tmp_path, monkeypatch, debug, outcome, slow_seconds,
):
    clock = {"seconds": 0.0, "waits": 0}
    monkeypatch.setattr(parallel_module.time, "monotonic", lambda: clock["seconds"])

    class FakeConnection:
        def recv(self):
            if outcome == "completed" and clock["waits"] == 4:
                return WorkerResponse(lane_id=0, instance_id="generated")
            return WorkerProgress(
                lane_id=0, command="generate_online", timestamp=time.time(),
                payload={"generation_attempt": clock["waits"]},
            )

    connection = FakeConnection()

    def fake_wait(connections, *, timeout):
        assert connections == [connection]
        clock["waits"] += 1
        if outcome == "stall_timeout" and clock["waits"] > 1:
            clock["seconds"] += 1.1
            return []
        clock["seconds"] += 0.6
        return [connection]

    monkeypatch.setattr(parallel_module, "wait", fake_wait)
    runner = object.__new__(ParallelEpisodeRunner)
    runner.config = config
    runner.diagnostic_directory = tmp_path
    runner.debug_worker_steps = debug
    runner.timeout_seconds = 3.0
    runner.stall_timeout_seconds = 1.0
    runner.slow_instance_seconds = slow_seconds
    runner._connections = [connection]
    runner._lane_command_started = {0: 0.0}
    runner._lane_command_serial = {0: 1}
    runner._lane_command_name = {0: "generate_online"}
    runner._latest_progress = {}
    runner._slow_command_serial = {}
    runner._lane_instances = {}
    runner._last_logged_error = None
    runner._start_instance(0, ("generate_online", 0), 0.0)
    if outcome == "completed":
        assert runner._receive_responses([0])[0].instance_id == "generated"
    else:
        with pytest.raises(ParallelWorkerTimeout, match=outcome):
            runner._receive_responses([0])
    assert runner._latest_progress[0]["event"] == "heartbeat"
    assert runner._latest_progress[0]["generation_attempt"] >= 1
    assert runner._lane_instances == {}
    assert len(runner._slow_command_serial) <= 1
    events = _worker_events(tmp_path)
    assert events[0]["event"] == "instance_start"
    assert events[-1]["event"] == "instance_end"
    assert not any(event["event"] == "heartbeat" for event in events)
    if outcome != "completed":
        error = next(event for event in events if event["event"] == "error")
        assert error["error_type"] == "ParallelWorkerTimeout"
        assert outcome in error["message"]
        assert error["latest_progress"] == runner._latest_progress[0]
        assert events[-1]["terminal_reason"] == "error"
    slow_events = [event for event in events if event["event"] == "slow_task"]
    assert len(slow_events) == (1 if slow_seconds == 0.1 else 0)
    if slow_events:
        assert len((tmp_path / "slow_instances.jsonl").read_text().splitlines()) == 1


def test_worker_debug_steps_requires_boolean(config, fixed_instance):
    effective = deepcopy(config)
    effective["logging"]["worker_progress"]["debug_steps"] = "false"
    with pytest.raises(ValueError, match="debug_steps must be boolean"):
        ParallelEpisodeRunner(
            config=effective, template=fixed_instance, episode_count=1, worker_count=1,
        )


@pytest.mark.parametrize("already_recorded", [False, True])
def test_runner_logs_parent_exception_once_even_without_an_active_instance(tmp_path, already_recorded):
    runner = object.__new__(ParallelEpisodeRunner)
    runner.diagnostic_directory = tmp_path
    runner._lane_instances = {}
    runner._lane_command_name = {}
    runner._lane_command_serial = {}
    runner._latest_progress = {}
    runner._last_logged_error = None
    closed = []
    runner.close = lambda *, force: closed.append(force)
    try:
        raise ParallelWorkerError("incomplete rollout")
    except ParallelWorkerError as error:
        if already_recorded:
            runner._record_worker_error(None, error)
        runner.__exit__(type(error), error, error.__traceback__)
    events = _worker_events(tmp_path)
    assert len(events) == 1
    assert events[0]["event"] == "error"
    assert events[0]["lane"] is None
    assert "incomplete rollout" in events[0]["traceback"]
    assert closed == [True]


@pytest.mark.slow
def test_training_indices_220_239_repeat_three_times_with_twenty_workers(
    fixed_instance,
    tmp_path,
):
    effective = load_config("configs/e1/single_flow.json")
    effective["device"] = "cpu"
    effective["paths"]["training_instances_cache"] = str(
        tmp_path / "cache"
    )
    effective["training"]["worker_timeout_seconds"] = 600
    effective["training"]["worker_stall_timeout_seconds"] = 60
    with ParallelEpisodeRunner(
        config=effective,
        template=fixed_instance,
        episode_count=2000,
        worker_count=20,
        diagnostic_directory=tmp_path / "diagnostics",
    ) as runner:
        reports = [
            runner.pre_generate_training_instances(range(220, 240))
            for _ in range(3)
        ]
    hashes = [
        [entry["sha256"] for entry in report["files"]]
        for report in reports
    ]
    assert hashes[0] == hashes[1] == hashes[2]
    assert all(report["generator_version"] == "2.0.0" for report in reports)
    assert reports[1]["cache_hit_count"] == 20
    assert reports[2]["cache_hit_count"] == 20
